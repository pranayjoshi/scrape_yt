# scrape_yt
** This is a simple Youtube video and playlist downloader.

# Installation
* Just run the setup.py by ``` python setup.py ```
* Cngratulations your youtube video downloader is installed.